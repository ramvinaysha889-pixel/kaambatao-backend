# Tavunera

> One AI for Everything

**Note on structure:** `index.html`, `style.css`, and `app.js` are kept at
the **root** of this project (not inside a `frontend/` folder) so this repo
can be deployed directly with **GitHub Pages**. The `backend/` folder is
separate and deploys separately (e.g. on Render) — it is unchanged from
before.

---

# KaamBatao (legacy notes below)

> "Jo samajh nahi aaye, uski photo bhejo."

A mobile-first web app where users upload a photo of a confusing document
(bill, form, notice, screenshot) and get a simple Hindi+English explanation:
what it is, key info, what to do next, and a checklist.

This is the **MVP**: a real, working frontend + a backend that is fully wired
to call a real AI vision API. It ships with **no fake/hardcoded results** —
until you add an API key, the app will honestly tell you the AI isn't
configured yet, instead of pretending to analyze anything.

---

## 1. Project structure

```
kaambatao/
├── frontend/                 → Static site, no build step needed
│   ├── index.html            → All 4 screens (Home, Upload, Analysis, Result)
│   ├── css/style.css         → Mobile-first design system
│   └── js/app.js             → Screen navigation, upload, API calls
│
└── backend/                  → Node.js/Express API server
    ├── server.js             → Server entry point
    ├── routes/analyze.js     → POST /api/analyze → calls Claude vision API
    ├── package.json          → Dependencies
    ├── .env.example          → Template for your secret API key
    └── .gitignore
```

**Why split like this?** The frontend never talks to the AI API directly —
it only talks to *your own* backend. Your AI API key lives only on the
backend server, so it can never be stolen from the browser. This is the
standard, secure way to build apps like this.

---

## 2. What each important file does

- **`frontend/index.html`** — The whole app as one page. It has 4 `<section>`
  blocks (Home, Upload, Analysis, Result) that get shown/hidden by JavaScript
  instead of separate page loads — this keeps it fast on mobile.
- **`frontend/css/style.css`** — All styling: colors, spacing, buttons,
  loading animation, result cards. Built mobile-first (390px width) and
  scales up nicely on larger screens.
- **`frontend/js/app.js`** — All app behavior: switching screens, picking a
  photo (gallery or camera), showing a preview, calling your backend's
  `/api/analyze` endpoint, and rendering the result. It never invents fake
  data — if the API call fails, it shows a clear error.
- **`backend/server.js`** — Starts the Express server, sets up CORS (so your
  frontend is allowed to call it), and mounts the analyze route.
- **`backend/routes/analyze.js`** — Receives the uploaded image, sends it to
  Claude's vision API with a prompt that asks for the exact JSON shape the
  frontend expects, and returns that JSON. Returns a clear error if the API
  key isn't set — never fakes a result.
- **`backend/.env.example`** — Template showing which secret values the
  server needs (your AI API key). You copy this to a real `.env` file that
  you never upload to GitHub.

---

## 3. How to run the project

Since you're doing this from a phone, the easiest path is to **skip running
anything locally** and go straight to deployment (Section 5) — both Netlify
and Render build and run the code for you in the cloud. You don't need
Node.js installed on your phone at all.

If you *do* later use a laptop/desktop, local run looks like this:

**Frontend** (no build step):
```
cd frontend
# open index.html in a browser, or serve it with any static server, e.g.:
npx serve .
```

**Backend**:
```
cd backend
cp .env.example .env      # then paste your API key into .env
npm install
npm start                 # runs on http://localhost:4000
```

When running locally, also change `API_URL` in `frontend/js/app.js` to
`http://localhost:4000/api/analyze`.

---

## 4. How to connect a real AI vision API

The backend is already fully wired for Claude's vision API — you only need
to supply a key:

1. Get an API key from https://console.anthropic.com
2. On your hosting platform (see Section 5), add an environment variable:
   - `ANTHROPIC_API_KEY` = your key
3. That's it — `backend/routes/analyze.js` already sends the image to
   `https://api.anthropic.com/v1/messages` and asks for the exact JSON shape
   the Result screen needs (`documentType`, `whatIsIt`, `importantInfo`,
   `nextSteps`, `checklist`).

Want to use a different AI vision provider (OpenAI, Google Gemini, etc.)
instead? You only need to edit **one file** — `backend/routes/analyze.js` —
and change the `fetch(...)` call to that provider's API. The frontend
never needs to change, since it only expects that same JSON shape back.

---

## 5. How to deploy it online (from your phone)

You'll deploy the **frontend** and **backend** to two free services, both of
which have mobile-friendly websites and connect directly to GitHub.

### Step A — Put the code on GitHub
1. On your phone, open the **GitHub** app (or github.com in your browser)
   and sign in / create a free account.
2. Create a new repository, e.g. `kaambatao`.
3. Use GitHub's "Add file → Upload files" (in the mobile browser, tap
   "Desktop site" in your browser menu first, it makes this screen easier
   to use) and upload the whole `kaambatao` folder — both `frontend/` and
   `backend/` subfolders.

### Step B — Deploy the backend (Render.com)
1. Go to https://render.com and sign up (you can log in with GitHub).
2. Tap **New → Web Service**.
3. Connect your `kaambatao` GitHub repo.
4. Set **Root Directory** to `backend`.
5. Build command: `npm install` — Start command: `npm start`.
6. Under **Environment**, add `ANTHROPIC_API_KEY` with your real key.
7. Deploy. Render gives you a URL like `https://kaambatao-backend.onrender.com`.

### Step C — Deploy the frontend (Netlify)
1. Go to https://netlify.com and sign up.
2. Tap **Add new site → Import from GitHub**, pick your `kaambatao` repo.
3. Set **Base directory** to `frontend`, leave build command empty (there's
   no build step), and **Publish directory** to `frontend`.
4. Before deploying, edit `frontend/js/app.js` in GitHub's web editor and
   change:
   ```js
   API_URL: "/api/analyze",
   ```
   to your Render backend URL:
   ```js
   API_URL: "https://kaambatao-backend.onrender.com/api/analyze",
   ```
5. Deploy. Netlify gives you a live URL like `https://kaambatao.netlify.app`
   — open it on your phone and try it out.

That's it — you now have a real, live app with a secure backend, ready to
have a real AI vision API connected.
